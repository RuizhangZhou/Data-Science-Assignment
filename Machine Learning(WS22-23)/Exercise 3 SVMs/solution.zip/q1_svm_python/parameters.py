def parameters():
    C = 1000
    C2 = 1000
    norm = 5
    return [C, C2, norm]
